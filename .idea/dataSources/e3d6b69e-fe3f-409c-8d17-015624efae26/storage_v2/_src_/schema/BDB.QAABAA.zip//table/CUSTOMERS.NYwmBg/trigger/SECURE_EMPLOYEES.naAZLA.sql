create trigger SECURE_EMPLOYEES
  before insert or update or delete
  on CUSTOMERS
  BEGIN
    secure_dml;
  END secure_employees;
/

